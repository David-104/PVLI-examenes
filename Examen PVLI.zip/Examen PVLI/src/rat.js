import Ball from "./ball.js";
import ThrownBall from "./thrownBall.js";

export default class Rat extends Phaser.Physics.Arcade.Sprite {
    constructor(scene, x, y) {
        super(scene, x, y, 'rat');
        this.scene.add.existing(this);
        this.scene.physics.world.enable(this);

        //this.setDepth(5); profundidad, valor mas alto mas delante
        this.stunned = false;
        this.onBall = false;
        this.ball;
        this.carryingBall = false;
        this.numBalls = 5;
        // Ajustar el tamaño del cuerpo de físicas para que coincida con el sprite visual
        this.body.setSize(32, 32);
        this.body.setImmovable(true);
        this.cursors = scene.input.keyboard.addKeys({
            space: Phaser.Input.Keyboard.KeyCodes.DOWN,
            left: Phaser.Input.Keyboard.KeyCodes.LEFT,
            right: Phaser.Input.Keyboard.KeyCodes.RIGHT
        });

        this.throwInputBuffer; //variable para conseguir una unica lectura del teclado al lanzar

        this.carriedBall;
    }

    preUpdate(t, dt) {
        if (this.scene.playing) {
            super.preUpdate(t, dt); //que son la t y dt? ni idea pero hacen falta para las animaciones
            if (!this.stunned)
                this.movement();
            else {
                const endStun = () => {
                    this.stunned = false;
                    if (this.carryingBall)
                        this.anims.play('ratIdleBall', true);
                    else
                        this.anims.play('ratIdle', true);
                }
                this.scene.time.addEvent({
                    delay: (2000),
                    loop: false,
                    callback: endStun,
                    callbackScope: this
                });
            }
        }
        else {
            this.setVelocity(0, 0)
        }
    }

    movement() {
        if (this.cursors.left.isDown) {
            this.setVelocityX(-75)
            if (this.carryingBall)
                this.anims.play('ratMoveBall', true);
            else
                this.anims.play('ratMove', true);
        }
        else if (this.cursors.right.isDown) {
            this.setVelocityX(75)
            if (this.carryingBall)
                this.anims.play('ratMoveBall', true);
            else
                this.anims.play('ratMove', true);
        }
        else {
            this.setVelocityX(0)
            if (this.carryingBall)
                this.anims.play('ratMoveBall', true);
            else
                this.anims.play('ratMove', true);
        }

        if (this.cursors.space.isDown) {
            if (!this.throwInputBuffer) {
                if (this.carryingBall) {
                    let ballThrown = new ThrownBall(this.scene, this.x, this.y, 'rat')
                    this.carryingBall = false;
                    this.numBalls--;
                    this.carriedBall.destroy();
                }
                else if (this.onBall && !this.carryingBall) {
                    this.ball.destroy();
                    this.carriedBall = this.scene.add.image(this.x, this.y, 'ball')
                    this.onBall = false;
                    this.carryingBall = true;
                }
            }
            this.throwInputBuffer = true;
        }
        else {
            this.throwInputBuffer = false;
        }

        //bordes mesa
        if (this.x < 115) {
            this.setVelocityX(10)
        }
        else if (this.x > 351) {
            this.setVelocityX(-10)

        }

        if (this.carryingBall) {
            this.carriedBall.x = this.x - 20;
            this.carriedBall.y = this.y;
        }
    }

    pickUpBall(ball) {
        this.onBall = true;
        this.ball = ball;
    }

    hit(ball) {
        this.anims.play('ratStun', true);
        this.stunned = true;
        this.addBallToSide(ball)
    }


    addBallToSide(ball) {
        let x = ball.x
        ball.destroy();
        let newBall = new Ball(this.scene, x, this.y);
        this.numBalls++;
    }
}